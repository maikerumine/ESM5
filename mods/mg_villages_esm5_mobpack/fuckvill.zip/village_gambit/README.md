
New village type for https://github.com/Sokomine/mg_villages/

This mod does depend on mg_villages.

The buildings found in this mod (in the schems/ folder) have been built by Gambit
for the peaceful_npc mod and have been extracted from the village he built
for them. See here: https://forum.minetest.net/memberlist.php?mode=viewprofile&u=398
