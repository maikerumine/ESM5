
New village type for https://github.com/Sokomine/mg_villages/

This mod does depend on mg_villages.

The buildings found in this mod (in the schems/ folder) have been built by
AgentNagel42. See https://forum.minetest.net/viewtopic.php?f=5&t=13297

