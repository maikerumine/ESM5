
New village type for https://github.com/Sokomine/mg_villages/

This mod does depend on mg_villages.

The buildings found in this mod (in the schems/ folder) have been built by
BorisGrishenko. See https://forum.minetest.net/viewtopic.php?f=12&t=10705

There are only three houses in this village type. More ought to be added.
